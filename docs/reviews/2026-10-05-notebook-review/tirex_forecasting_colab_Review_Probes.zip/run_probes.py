"""TRX review probes (torch-free; needs numpy and pandas). Usage: python run_probes.py <repo checkout> <out dir>"""
import json, os, sys, types, re, importlib, math
from pathlib import Path
import numpy as np

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/tirex_forecasting_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
V = importlib.import_module('tirex_forecasting_pipeline.validation'); E = importlib.import_module('tirex_forecasting_pipeline.evaluation'); P = importlib.import_module('tirex_forecasting_pipeline.pipeline')
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']; md = [i for i, c in enumerate(cells) if c['cell_type'] == 'markdown']
alltext = '\n'.join(src(i) for i in range(len(cells)))
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'pins': re.findall(r"'([A-Za-z0-9_.-]+==[^']+)'", src(3)),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Next experiments', 'Conclusion', '<details>']},
    'checkpoint_file': P.WEIGHTS_FILE, 'weights_only_mentioned_in_markdown': any('weights_only' in src(i) for i in md),
    'horizon_is_form_field': bool(re.search(r'HORIZON = \d+\s+# @param', src(13)))}

# P2 default sample, holdout and baselines (the default-path numbers that need no model)
rng = np.random.default_rng(7); t = np.arange(256)
noise = rng.normal(0, 0.05, len(t))
series = (0.02 * t + np.sin(t / 8) + noise)[None, :]
H = 32; ctx, truth = series[:, :-H], series[:, -H:]
lv = E.last_value_baseline(ctx, H)
period = int(round(2 * math.pi * 8))
snaive = np.array([[ctx[0, -period + (h % period)] for h in range(H)]])
# least-squares fit of the known functional family (trend + sin/cos at frequency 1/8 rad) on the context only
X = lambda tt: np.stack([np.ones_like(tt, dtype=float), tt, np.sin(tt / 8), np.cos(tt / 8)], 1)
coef, *_ = np.linalg.lstsq(X(t[:-H].astype(float)), ctx[0], rcond=None)
fit = (X(t[-H:].astype(float)) @ coef)[None, :]
noise_only = truth - (0.02 * t[-H:] + np.sin(t[-H:] / 8))[None, :]
R['P2_default_sample'] = {'shape': list(series.shape), 'float32_sha256': __import__('hashlib').sha256(np.ascontiguousarray(series, dtype=np.float32).tobytes()).hexdigest(),
    'context_length': ctx.shape[1], 'horizon': H,
    'last_value': {'mae': round(E.mae(truth, lv), 4), 'rmse': round(E.rmse(truth, lv), 4)},
    'seasonal_naive_period_50': {'mae': round(E.mae(truth, snaive), 4), 'rmse': round(E.rmse(truth, snaive), 4)},
    'least_squares_trend_plus_season_on_context': {'mae': round(E.mae(truth, fit), 4), 'rmse': round(E.rmse(truth, fit), 4)},
    'noise_floor_on_holdout_(oracle_signal)': {'mae': round(float(np.mean(np.abs(noise_only))), 4), 'rmse': round(float(np.sqrt(np.mean(noise_only ** 2))), 4)},
    'recorded_local_preflight_2026-09-11 (earlier blob)': {'tirex_mae': 0.0491, 'tirex_rmse': 0.0646, 'last_value_mae': 0.6729, 'last_value_rmse': 0.7468},
    'recorded_for_reviewed_blob_2026-09-14': 'no metrics recorded (10/10 ok, 262.0 s, 8 files, 381 MB)',
    'coverage_granularity': 'q10-q90 coverage over 32 holdout points moves in steps of 1/32 = 0.03125'}

# P3 BYOD branch of cell 13 with stand-ins (Colab writes uploads into the working directory)
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True')
work = (out / 'work').resolve(); work.mkdir(exist_ok=True)
def exec13(files_map, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm
        def upload():
            for n, d in files_map.items(): (work / n).write_bytes(d)
            return dict(files_map)
        cm.files = types.SimpleNamespace(upload=upload); sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(work)
    try:
        ns = {'np': np, 'validate_target': V.validate_target, 'MIN_CONTEXT': V.MIN_CONTEXT}
        exec(compile(c13, 'cell13', 'exec'), ns)
        ctxv = ns['series'][:, :-H]
        P.validate_inputs(ctxv, horizon=H, names=ns['variate_names'])
        return {'shape': list(ns['series'].shape), 'variates': ns['variate_names']}
    finally:
        os.chdir(cwd)
def csv_(n, extra_cols='', start='2024-01-01', freq='D', mutate=None, sep=','):
    import pandas as pd
    ts = pd.date_range(start, periods=n, freq=freq).strftime('%Y-%m-%d %H:%M:%S').tolist()
    lines = [sep.join(['timestamp', 'load'] + ([extra_cols] if extra_cols else []))]
    for i, s in enumerate(ts):
        row = [s, f'{10 + math.sin(i / 5):.4f}'] + (['x'] if extra_cols else [])
        lines.append(sep.join(row))
    if mutate: lines = mutate(lines)
    return ('\n'.join(lines) + '\n').encode()
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:220]}
cases = [
    run('200 daily rows, one target', lambda: exec13({'a.csv': csv_(200)})),
    run('63 rows (one short of 32 + 32)', lambda: exec13({'b.csv': csv_(63)})),
    run('20,000 hourly rows', lambda: exec13({'c.csv': csv_(20000, freq='h')})),
    run('duplicate header', lambda: exec13({'d.csv': csv_(200, mutate=lambda L: ['timestamp,load,load'] + [l + ',1' for l in L[1:]])})),
    run('text column besides the target', lambda: exec13({'e.csv': csv_(200, extra_cols='note')})),
    run('one empty value', lambda: exec13({'f.csv': csv_(200, mutate=lambda L: L[:10] + [L[10].split(',')[0] + ','] + L[11:])})),
    run('one missing day (irregular)', lambda: exec13({'g.csv': csv_(200, mutate=lambda L: L[:50] + L[51:])})),
    run('semicolon-delimited', lambda: exec13({'h.csv': csv_(200, sep=';')})),
    run('UTF-8 BOM', lambda: exec13({'i.csv': b'\xef\xbb\xbf' + csv_(200)})),
    run('cancelled dialog', lambda: exec13({})),
    run('outside Colab', lambda: exec13(None, colab=False)),
]
R['P3_byod'] = {'matrix': cases, 'has_path_field': bool(re.search(r'BYOD_(PATH|CSV)\s*=', src(13))), 'MAX_CONTEXT': V.MAX_CONTEXT}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
import shutil; shutil.rmtree(work, ignore_errors=True)
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:8000])
